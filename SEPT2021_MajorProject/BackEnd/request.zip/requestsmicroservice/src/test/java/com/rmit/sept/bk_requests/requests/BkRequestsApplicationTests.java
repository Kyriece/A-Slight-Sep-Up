package com.rmit.sept.bk_requests.requests;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BkRequestsApplicationTests {

	@Test
	void contextLoads() {
	}

}
