package com.rmit.sept.bk_requests.requests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BkRequestsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BkRequestsApplication.class, args);
	}

}
